# English to Urdu AI Translator

A Gradio application that translates English text into Urdu or Roman Urdu using Google's Gemini API.

## Required environment variable

Set `GEMINI_API_KEY` in your hosting provider's environment-variable or secrets settings. Do not commit the API key to this repository.

## Run locally

```bash
pip install -r requirements.txt
# Set GEMINI_API_KEY in your environment, then:
python app.py
```

The app uses the `gemini-3.5-flash-lite` model. Model availability, quotas, and API pricing depend on your Google AI Studio project.
